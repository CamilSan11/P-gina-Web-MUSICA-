INSERT INTO MUSICA.Artista (ID_Artista, Artista, Nombre_de_la_cancion, Fecha_de_lanzamiento, Album, Link) VALUES
(NULL, 'Siddhartha', 'Únicos', '2016-08-26', 'Únicos', 'https://www.youtube.com/watch?v=wK_USczZeys&pp=ygUGdW5pY29z'),
(NULL, 'Siddhartha', 'Náufrago', '2011-06-24', 'Náufrago', 'https://www.youtube.com/watch?v=xgyJsfXkD_4&pp=ygUIbmF1ZnJhZ28%3D'),
(NULL, 'Siddhartha', 'Respiro', '2019-09-24', 'Memoria Futuro', 'https://www.youtube.com/watch?v=QoB5Gpq44OM&pp=ygUHcmVzcGlybw%3D%3D'),

(NULL, 'Enjambre', 'Manía Cardíaca', '2010-08-30', 'Daltónico', 'https://www.youtube.com/watch?v=Yn5vQ66q7os&t=173s'),
(NULL, 'Enjambre', 'Dulce Soledad', '2008-09-15', 'El Segundo Es Felino', 'https://www.youtube.com/watch?v=LoUgRNpEgKE&pp=ygUNZHVsY2Ugc29sZWRhZA%3D%3D'),
(NULL, 'Enjambre', 'Visita', '2017-05-05', 'Imperfecto Extraño', 'https://www.youtube.com/watch?v=gbpsUoh-7kY&pp=ygUGdmlzaXRh'),

(NULL, 'Camilo Séptimo', 'Ser Humano', '2016-05-12', 'Óleos', 'https://www.youtube.com/watch?v=6Qipsjrerh8&pp=ygUhc2VyIGh1bWFubyBjYW1pbG8gc2VwdGltbyBlbiB2aXZv'),
(NULL, 'Camilo Séptimo', 'Vicio', '2020-01-31', 'Ecos', 'https://www.youtube.com/watch?v=C3w4zEhiytA&pp=ygUFdmljaW8%3D'),
(NULL, 'Camilo Séptimo', 'No Confíes en Mí', '2017-06-14', 'Óleos', 'https://www.youtube.com/watch?v=yyeALNlLRrA&pp=ygUfbm8gY29uZmllcyBlbiBtaSBjYW1pbG8gc2VwdGltbw%3D%3D'),

(NULL, 'Harry Styles', 'Sign of the Times', '2017-04-07', 'Harry Styles', 'https://www.youtube.com/watch?v=0ks_ihWn8wI'),
(NULL, 'Harry Styles', 'Watermelon Sugar', '2019-11-16', 'Fine Line', 'https://www.youtube.com/watch?v=E07s5by4Iw8'),
(NULL, 'Harry Styles', 'As It Was', '2022-04-01', 'Harry’s House', 'https://www.youtube.com/watch?v=H5Wn0M7xO08'),

(NULL, 'Tame Impala', 'The Less I Know the Better', '2015-07-17', 'Currents', 'https://www.youtube.com/watch?v=4bU3bY58UTo'),
(NULL, 'The Strokes', 'Reptilia', '2003-02-09', 'Room on Fire', 'https://www.youtube.com/watch?v=im6A9x4r0-4'),
(NULL, 'Foals', 'My Number', '2013-01-24', 'Holy Fire', 'https://www.youtube.com/watch?v=F-j_rhdu2hE'),
(NULL, 'Zoé', 'Love', '2005-06-15', 'Memo Rex Commander', 'https://www.youtube.com/watch?v=HOS7jllJj0A'),
(NULL, 'Caifanes', 'La Negra Tomasa', '1988-08-11', 'Caifanes', 'https://www.youtube.com/watch?v=F95f7AwwU3g'),
(NULL, 'Arctic Monkeys', 'I Bet You Look Good on the Dancefloor', '2005-10-17', 'Whatever People Say I Am', 'https://www.youtube.com/watch?v=0nYg5G1I8N8'),

(NULL, 'The 1975', 'Somebody Else', '2016-02-15', 'I like it when you sleep...', 'https://www.youtube.com/watch?v=U2A1ptU3QRU'),
(NULL, 'Coldplay', 'Adventure of a Lifetime', '2015-11-06', 'A Head Full of Dreams', 'https://www.youtube.com/watch?v=8P38G0UUE3E'),
(NULL, 'Billie Eilish', 'Everything I Wanted', '2019-11-13', 'Single', 'https://www.youtube.com/watch?v=ViwtNLUq3yI'),
(NULL, 'The Weeknd', 'Save Your Tears', '2020-11-24', 'After Hours', 'https://www.youtube.com/watch?v=XXD5R3N1cGo'),
(NULL, 'Muse', 'Supermassive Black Hole', '2006-06-19', 'Black Holes and Revelations', 'https://www.youtube.com/watch?v=GmIVdVauRNE'),
(NULL, 'Radiohead', 'No Surprises', '1997-05-21', 'OK Computer', 'https://www.youtube.com/watch?v=8bF1Vh0X7X8'),
(NULL, 'Queen', 'Another One Bites the Dust', '1980-08-22', 'The Game', 'https://www.youtube.com/watch?v=5e8c8W8MY5U'),

(NULL, 'David Bowie', 'Life on Mars?', '1971-06-22', 'Hunky Dory', 'https://www.youtube.com/watch?v=vGJx8G5Z14A'),
(NULL, 'The Beatles', 'Come Together', '1969-10-06', 'Abbey Road', 'https://www.youtube.com/watch?v=45cYwDM9YDA'),
(NULL, 'Adele', 'Someone Like You', '2011-01-24', '21', 'https://www.youtube.com/watch?v=hLQl3WQQoQ'),
(NULL, 'Ed Sheeran', 'Thinking Out Loud', '2014-06-23', 'X (Multiply)', 'https://www.youtube.com/watch?v=lp-EO5Iu0wU'),
(NULL, 'The Rolling Stones', 'Angie', '1973-08-20', 'Goats Head Soup', 'https://www.youtube.com/watch?v=9eR8g2vTi8A'),
(NULL, 'Pink Floyd', 'Time', '1973-03-01', 'The Dark Side of the Moon', 'https://www.youtube.com/watch?v=Y8KJx1eW64U');
