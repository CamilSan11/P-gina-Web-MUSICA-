CREATE TABLE MUSICA.Artista (
    ID_Artista INT AUTO_INCREMENT NOT NULL,
    Artista VARCHAR(55) NOT NULL,
    Nombre_de_la_cancion VARCHAR(255) NOT NULL,
    Fecha_de_lanzamiento DATE NOT NULL,
    Album VARCHAR(255) NOT NULL,
    Link VARCHAR(255),  
    PRIMARY KEY(ID_Artista)
) ENGINE=InnoDB;
