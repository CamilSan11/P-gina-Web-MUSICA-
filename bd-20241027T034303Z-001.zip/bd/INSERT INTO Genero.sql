INSERT INTO MUSICA.Genero(ID_Genero,Nombre_genero)
VALUES('NULL','Masculino'),('NULL','Femenino'),('NULL','Prefiero no decirlo');

