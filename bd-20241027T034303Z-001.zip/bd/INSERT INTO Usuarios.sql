INSERT INTO MUSICA.Usuarios(ID_Usuarios,Nombre,ApellidoP,ApellidoM,Fechnac,ID_Genero,Telefono,Email,Nombre_de_usuario,Password)
VALUES('NULL','Angel','Alvarez','Gonzalez','2007-06-05','1','5524182995','aalvarezg@gmail.com','Alvarezxz','1234'),
('NULL','Camila','Sandoval','Garcia','2005-03-11','2','5514532345','cam05gmail.com','Camill11','2005'),
('NULL','Mariam Andrea','Martinez','Martinez','2007-07-19','2','5534213454','mar12@gmail.com','Mar24mrtz','13245'),
('NULL','Adriana Lizbeth','Vazquez','Juarez','2005-07-08','2','5523451234','lizvaz@gmail.com','lizvj65','123456'),
('NULL','Jose Luis','Chavez','Gomez','1984-11-08','1','5523454561','chavezg@gmail.com','joseg234','345231');
